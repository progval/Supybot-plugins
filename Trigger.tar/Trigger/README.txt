Trigger is a very basic plugin, that allows channel ops to trigger commands
by an event on there channel (join, part, quit, ...), through the
configuration.
